### Fusion Block Transitions 1.0.1
- Updated resource pack icon

### Fusion Block Transitions 1.0.0
- Initial release of Fusion Block Transitions
