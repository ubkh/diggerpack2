### Fusion Block Transitions 1.0.1
- Fixed log spam on Minecraft versions with polished tuff

### Fusion Block Transitions 1.0.0
- Initial release of Fusion Connected Blocks
