execute as @e[type=minecraft:end_crystal] run data modify entity @s Invulnerable set value false
