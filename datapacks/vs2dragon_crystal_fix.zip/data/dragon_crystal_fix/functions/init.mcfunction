scoreboard objectives add dragon_check dummy
