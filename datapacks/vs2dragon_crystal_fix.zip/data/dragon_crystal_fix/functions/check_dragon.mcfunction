execute if entity @e[type=minecraft:ender_dragon] run function dragon_crystal_fix:main
